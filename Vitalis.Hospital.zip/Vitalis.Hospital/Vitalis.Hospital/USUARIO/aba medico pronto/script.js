// Lista de médicos
const medicos = {
  joao: { nome:"Dr. João Silva", especialidade:"Cardiologia", contato:"(11) 99999-0000", valor:"R$ 250", local:"São Paulo", foto:"https://via.placeholder.com/280" },
  maria: { nome:"Dra. Maria Costa", especialidade:"Cardiologia", contato:"(21) 98888-1111", valor:"R$ 300", local:"Rio de Janeiro", foto:"https://via.placeholder.com/280" },
  ana: { nome:"Dra. Ana Souza", especialidade:"Pediatria", contato:"(31) 97777-2222", valor:"R$ 200", local:"Belo Horizonte", foto:"https://via.placeholder.com/280" },
  carlos: { nome:"Dr. Carlos Lima", especialidade:"Ortopedia", contato:"(41) 96666-3333", valor:"R$ 280", local:"Curitiba", foto:"https://via.placeholder.com/280" },
  julia: { nome:"Dra. Julia Mendes", especialidade:"Dermatologia", contato:"(51) 95555-4444", valor:"R$ 350", local:"Porto Alegre", foto:"https://via.placeholder.com/280" }
};

// Ao carregar a página
document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll(".card");

  // Clique no card -> vai para detalhes.html?id
  cards.forEach(card => {
    card.addEventListener("click", () => {
      const id = card.getAttribute("data-id");
      window.location.href = `detalhes.html?id=${id}`;
    });
  });

  // Se estamos em detalhes.html, preencher infos
  if (window.location.href.includes("detalhes.html")) {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");
    if (id && medicos[id]) {
      document.getElementById("nome").innerText = medicos[id].nome;
      document.getElementById("especialidade").innerText = medicos[id].especialidade;
      document.getElementById("contato").innerText = medicos[id].contato;
      document.getElementById("valor").innerText = medicos[id].valor;
      document.getElementById("local").innerText = medicos[id].local;
      document.getElementById("foto").src = medicos[id].foto;
    }
  }
});
