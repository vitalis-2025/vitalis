function comeceAgora() {
    alert("Redirecionando para o início do atendimento...");
    // window.location.href = "inicio.html"; // Exemplo de redirecionamento
  }
  
  function entrarNoSite() {
    alert("Entrando no site...");
    // window.location.href = "home.html"; // Exemplo de redirecionamento
  }