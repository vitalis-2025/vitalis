function saibaMais() {
  alert("Você será redirecionado para saber mais sobre nossos serviços em breve!");
}


  let index = 0;
  const links = document.querySelectorAll(".carrossel a");
  const totalSlides = links.length;

  function mostrarProximoSlide() {
    links[index].firstElementChild.classList.remove("ativo");
    index = (index + 1) % totalSlides;
    links[index].firstElementChild.classList.add("ativo");
  }

  setInterval(mostrarProximoSlide, 3000); // troca a cada 3 segundos

  let slideIndex = 0;
  let slides = document.querySelectorAll(".carousel-slide");
  let dots = document.querySelectorAll(".dot");
  let prevBtn = document.querySelector(".prev");
  let nextBtn = document.querySelector(".next");
  
  // Variável para armazenar o intervalo de tempo
  let autoSlideInterval;
  
  function showSlide(index) {
    if (index >= slides.length) slideIndex = 0;
    if (index < 0) slideIndex = slides.length - 1;
  
    slides.forEach((slide, i) => {
      slide.classList.remove("active");
      dots[i].classList.remove("active");
    });
  
    slides[slideIndex].classList.add("active");
    dots[slideIndex].classList.add("active");
  }
  
  function nextSlide() {
    slideIndex++;
    showSlide(slideIndex);
  }
  
  function prevSlide() {
    slideIndex--;
    showSlide(slideIndex);
  }
  
  function startAutoSlide() {
    // Atribui o setInterval à variável e inicia a troca automática
    autoSlideInterval = setInterval(nextSlide, 60000); // muda a cada 1m
  }
  
  function stopAutoSlide() {
    // Limpa o timer automático
    clearInterval(autoSlideInterval);
  }
  
  // Controles
  nextBtn.addEventListener("click", () => {
    stopAutoSlide(); // Para a automação
    nextSlide(); // Move para o próximo slide
  });
  
  prevBtn.addEventListener("click", () => {
    stopAutoSlide(); // Para a automação
    prevSlide(); // Move para o slide anterior
  });
  
  dots.forEach((dot, i) => {
    dot.addEventListener("click", () => {
      stopAutoSlide(); // Para a automação
      slideIndex = i;
      showSlide(slideIndex);
    });
  });
  
  // Inicia a automação quando a página carrega
  startAutoSlide();
  
  // Inicia o carrossel no primeiro slide
  showSlide(slideIndex);