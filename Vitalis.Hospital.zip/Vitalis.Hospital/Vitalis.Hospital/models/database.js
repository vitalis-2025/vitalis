const sequelize = require('sequelize')
const connection = new sequelize ('HospitalGabi', 'root', 'escola', {
    host : 'localhost',
    dialect : 'mysql',
    logging : false
});
module.exports = connection;